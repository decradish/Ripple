//
//  HTTP.h
//  Detix
//
//  Created by Shibu Devasia on 22/11/12.
//  Copyright (c) 2012 Affle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Ripple_HTTP : NSObject
@property (nonatomic,strong) NSString *url;
@property (nonatomic,strong) NSString *method;
@property (nonatomic,strong) NSString *param;
@property (nonatomic,strong) NSMutableData *response;
@property (nonatomic,strong) NSURLConnection *connection;
@property (nonatomic,strong) NSMutableURLRequest *request;
@property (nonatomic,strong) NSString *tag;
@property (nonatomic,strong) NSString *mimeType;
@property (nonatomic,strong) id delegate;
- (id) initWithURL:(NSString*)url delegate:(id)delegate;
- (void) start;
@end

@protocol Ripple_HTTPDelegate <NSObject>
@optional
- (void) onHttpFinish:(BOOL)status data:(NSData*)data mimeType:(NSString*)mimeType tag:(NSString*)tag;
@end