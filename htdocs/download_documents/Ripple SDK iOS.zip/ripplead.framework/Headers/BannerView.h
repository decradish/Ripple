//
//  BannerView.h
//  mobilesdk
//
//  Created by Shibu Devasia on 28/1/13.
//  Copyright (c) 2013 Ripple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RippleBaseView.h"

@interface BannerView : RippleBaseView

@end
