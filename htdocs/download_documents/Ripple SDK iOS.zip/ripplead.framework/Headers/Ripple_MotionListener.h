//
//  Ripple_MotionListener.h
//  mobilesdktest
//
//  Created by Shibu Devasia on 19/3/13.
//  Copyright (c) 2013 Ripple. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol Ripple_MotionListenerDelegate <NSObject>
@optional
- (void) didAccelerometerUpdate:(double)x y:(double)y z:(double)z;
@end

@interface Ripple_MotionListener : NSObject
+ (void) addListener:(id<Ripple_MotionListenerDelegate>)listener;
+ (void) removeListener:(id<Ripple_MotionListenerDelegate>)listener;
@end
