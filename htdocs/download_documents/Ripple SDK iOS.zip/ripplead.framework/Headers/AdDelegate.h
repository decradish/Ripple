//
//  AdDelegate.h
//  mobilesdktest
//
//  Created by Shibu Devasia on 14/3/13.
//  Copyright (c) 2013 Ripple. All rights reserved.
//

@protocol AdDelegate <NSObject>
@optional

- (void) onAdsLoad;
- (void) onNoAds;
- (void) onAdsSwitch;
- (void) onAdsPause;
- (void) onAdsResume;
- (void) onAdsFail;

@end