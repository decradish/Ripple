//
//  InterstitialView.h
//  mobilesdktest
//
//  Created by Shibu Devasia on 13/3/13.
//  Copyright (c) 2013 Ripple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RippleBaseView.h"

@interface InterstitialView : RippleBaseView

@end
