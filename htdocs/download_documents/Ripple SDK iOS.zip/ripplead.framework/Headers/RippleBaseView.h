//
//  RippleBaseView.h
//  mobilesdktest
//
//  Created by Shibu Devasia on 13/3/13.
//  Copyright (c) 2013 Ripple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import <EventKitUI/EventKitUI.h>
#import "Ripple_HTTP.h"
#import "AdDelegate.h"
#import <CoreLocation/CoreLocation.h>
#import "Ripple_MotionListener.h"

@interface RippleBaseView : UIView <Ripple_HTTPDelegate,UIWebViewDelegate,EKEventEditViewDelegate,CLLocationManagerDelegate,Ripple_MotionListenerDelegate,UIImagePickerControllerDelegate>
@property (nonatomic,strong) NSString *alias;
@property (nonatomic,strong) id <AdDelegate> delegate;
@property (assign) NSUInteger networkID;
@property (assign) NSUInteger subnetworkID;
@property (assign) NSUInteger refreshInterval;
@property (assign) BOOL visible;
@property (assign) int adType;
- (void) loadAd;
- (void) pauseAd;
- (void) resumeAd;
- (void) addKey:(NSString*)key value:(NSString*)value;
- (void) removeKey:(NSString*)key;
- (void) clearKeyValue;
@end
